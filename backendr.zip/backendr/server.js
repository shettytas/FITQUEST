const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

// SQLite database setup (no installation required)
const dbPath = path.join(__dirname, 'fitquest.db');
const db = new sqlite3.Database(dbPath);

// Initialize database tables
db.serialize(() => {
  // Users table
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Challenges table
  db.run(`CREATE TABLE IF NOT EXISTS challenges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    category TEXT,
    duration INTEGER,
    creator_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (creator_id) REFERENCES users (id)
  )`);

  // Progress table
  db.run(`CREATE TABLE IF NOT EXISTS progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    challenge_id INTEGER,
    current_progress INTEGER DEFAULT 0,
    target INTEGER,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (challenge_id) REFERENCES challenges (id)
  )`);

  // Insert sample challenges
  db.get("SELECT COUNT(*) as count FROM challenges", (err, row) => {
    if (row.count === 0) {
      const sampleChallenges = [
        ['10K Steps Daily', 'Walk 10,000 steps every day for 30 days', 'Steps', 30],
        ['3L Water Daily', 'Drink 3 liters of water daily for 21 days', 'Hydration', 21],
        ['30-Day Yoga Challenge', 'Complete daily yoga sessions for 30 days', 'Yoga', 30]
      ];
      
      const stmt = db.prepare("INSERT INTO challenges (title, description, category, duration) VALUES (?, ?, ?, ?)");
      sampleChallenges.forEach(challenge => {
        stmt.run(challenge);
      });
      stmt.finalize();
      console.log('Sample challenges added to database');
    }
  });
});

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, 'fitquest_secret', (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Routes (same API endpoints as before)
app.post('/api/register', async (req, res) => {
  const { name, email, password } = req.body;
  
  // Check if user exists
  db.get("SELECT * FROM users WHERE email = ?", [email], async (err, row) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    if (row) return res.status(400).json({ message: 'User already exists' });
    
    // Hash password and create user
    const hashedPassword = await bcrypt.hash(password, 10);
    db.run("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", 
      [name, email, hashedPassword], 
      function(err) {
        if (err) return res.status(500).json({ message: 'Error creating user' });
        
        const token = jwt.sign({ userId: this.lastID }, 'fitquest_secret', { expiresIn: '24h' });
        res.status(201).json({
          message: 'User created successfully',
          token,
          user: { id: this.lastID, name, email }
        });
      }
    );
  });
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  
  db.get("SELECT * FROM users WHERE email = ?", [email], async (err, user) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    if (!user) return res.status(400).json({ message: 'Invalid credentials' });
    
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: 'Invalid credentials' });
    
    const token = jwt.sign({ userId: user.id }, 'fitquest_secret', { expiresIn: '24h' });
    res.json({
      message: 'Login successful',
      token,
      user: { id: user.id, name: user.name, email: user.email }
    });
  });
});

app.get('/api/challenges', (req, res) => {
  db.all(`
    SELECT c.*, u.name as creator_name, 
           COUNT(p.user_id) as participant_count
    FROM challenges c 
    LEFT JOIN users u ON c.creator_id = u.id
    LEFT JOIN progress p ON c.id = p.challenge_id
    GROUP BY c.id
  `, (err, rows) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    res.json(rows);
  });
});

// Add other API endpoints here...

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`FitQuest server running on port ${PORT}`);
  console.log(`SQLite database created at: ${dbPath}`);
});